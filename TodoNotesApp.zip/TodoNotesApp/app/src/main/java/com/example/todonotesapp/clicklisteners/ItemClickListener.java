package com.example.todonotesapp.clicklisteners;

import com.example.todonotesapp.model.Notes;

public interface ItemClickListener {
    void onClick(Notes notes);
}
