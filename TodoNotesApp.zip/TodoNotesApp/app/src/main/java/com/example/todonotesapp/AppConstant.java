package com.example.todonotesapp;

public class AppConstant {
    public static String FULL_NAME = "full_name";
    public static String Title = "title";
    public static String Description = "description";
}
