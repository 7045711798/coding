package com.example.todonotesapp;

public class PrefConstant {

    public static String SHARED_PREFERENCE_NAME = "notes_app_pref";
    public static String IS_LOGGED_IN = "is_logged_in";
    public static String FULL_NAME = "full_name";
}
